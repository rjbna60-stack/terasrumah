<?php
require __DIR__.'/config.php';
$kode=strtoupper(preg_replace('/[^A-Za-z0-9]/','',(string)($_GET['kode'] ?? $_POST['kode'] ?? '')));
$o=null; $err='';
if($kode!==''){ $s=db()->prepare('SELECT * FROM pesanan WHERE kode=?'); $s->execute([$kode]); $o=$s->fetch(); }
if($o && $_SERVER['REQUEST_METHOD']==='POST' && $o['metode']!=='tunai' && $o['status_bayar']!=='lunas' && $o['status']!=='dibatalkan'){
  $f=$_FILES['bukti'] ?? null;
  if(!$f||$f['error']!==UPLOAD_ERR_OK) $err='Pilih foto bukti pembayaran terlebih dahulu.';
  else{
    [$n,$err]=simpan_gambar($f,__DIR__.'/assets/bukti','bukti_');
    if($n){
      if($o['bukti'] && is_file(__DIR__.'/assets/bukti/'.$o['bukti'])) @unlink(__DIR__.'/assets/bukti/'.$o['bukti']);
      db()->prepare("UPDATE pesanan SET bukti=?, status_bayar='menunggu_verifikasi' WHERE id=?")->execute([$n,$o['id']]);
      header('Location: pesanan.php?kode='.$kode.'&ok=1'); exit;
    }
  }
}
$items=[]; $set=pengaturan();
if($o){ $s=db()->prepare('SELECT * FROM pesanan_item WHERE pesanan_id=?'); $s->execute([$o['id']]); $items=$s->fetchAll(); }
?><!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pesanan <?= e($kode) ?> - Teras Rumah</title>
<style>
:root{--bg:#fbfaf6;--card:#fff;--ink:#26332b;--muted:#6a766d;--line:#e3e6dc;--green:#6f9d84;--gold:#c8923b;--soft:#e8f0ea}
@media(prefers-color-scheme:dark){:root{--bg:#17201b;--card:#1f2b24;--ink:#eef1e9;--muted:#a3b0a6;--line:#2f3d34;--soft:#243329}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 system-ui,sans-serif}
.w{max-width:640px;margin:0 auto;padding:20px}a{color:inherit}h1{font-size:26px;margin:8px 0}h2{font-size:18px;margin:0 0 8px}
.box{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px 18px;margin:14px 0}
.kode{font:700 30px/1.2 ui-monospace,monospace;letter-spacing:2px;color:var(--gold)}
.chip{display:inline-block;padding:3px 12px;border-radius:99px;background:var(--soft);font-weight:600;font-size:14px;margin:2px 4px 2px 0}
.chip.ok{background:var(--green);color:#10201a}.chip.bad{background:#f3c9c6;color:#7a1d18}
table{width:100%;border-collapse:collapse}td{padding:6px 0;border-bottom:1px solid var(--line)}td:last-child{text-align:right}
.btn{display:inline-block;background:var(--green);color:#10201a;font-weight:700;border:0;border-radius:10px;padding:10px 18px;text-decoration:none;cursor:pointer;font:inherit;font-weight:700}
input[type=file],input[type=text]{width:100%;margin:8px 0;padding:8px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:inherit;font:inherit}
.err{background:#f3c9c6;color:#7a1d18;padding:10px 14px;border-radius:10px}.okm{background:var(--soft);padding:10px 14px;border-radius:10px}
img.q{max-width:260px;width:100%;border-radius:12px;display:block;margin:8px 0}
</style></head><body><div class="w">
<a href="index.php">&larr; Kembali ke menu</a>
<?php if(!$o): ?>
<h1>Cek pesanan</h1>
<?php if($kode!=='') echo '<div class="err">Pesanan dengan kode '.e($kode).' tidak ditemukan.</div>'; ?>
<form class="box" method="get"><label>Kode pesanan<input type="text" name="kode" required></label><button class="btn">Cek</button></form>
<?php else: ?>
<h1>Pesanan Anda</h1>
<?php if(isset($_GET['ok'])) echo '<div class="okm">Bukti pembayaran diterima. Kasir akan memverifikasi pembayaran Anda.</div>'; ?>
<?php if($err) echo '<div class="err">'.e($err).'</div>'; ?>
<div class="box"><div>Kode pesanan (simpan kode ini)</div><div class="kode"><?= e($o['kode']) ?></div>
<p>Atas nama <b><?= e($o['nama']) ?></b> &middot; <?= $o['tipe']==='bawa_pulang'?'Bawa pulang':'Meja '.e($o['no_meja']) ?></p>
<span class="chip <?= $o['status']==='dibatalkan'?'bad':($o['status']==='selesai'?'ok':'') ?>">Pesanan: <?= e(SS[$o['status']]) ?></span>
<span class="chip <?= $o['status_bayar']==='lunas'?'ok':'' ?>">Pembayaran: <?= e(SB[$o['status_bayar']]) ?></span></div>
<div class="box"><h2>Rincian</h2><table>
<?php foreach($items as $i) echo '<tr><td>'.(int)$i['qty'].' &times; '.e($i['nama']).'</td><td>'.rp($i['harga']*$i['qty']).'</td></tr>'; ?>
<tr><td><b>Total</b></td><td><b><?= rp($o['total']) ?></b></td></tr></table>
<?php if($o['catatan']) echo '<p>Catatan: '.e($o['catatan']).'</p>'; ?></div>
<div class="box"><h2>Pembayaran: <?= e(METODE[$o['metode']]) ?></h2>
<?php if($o['status']==='dibatalkan'): ?><p>Pesanan ini dibatalkan.</p>
<?php elseif($o['status_bayar']==='lunas'): ?><p>Pembayaran sudah diterima. Terima kasih!</p>
<?php elseif($o['metode']==='tunai'): ?><p>Silakan bayar <b><?= rp($o['total']) ?></b> di kasir dan sebutkan kode pesanan Anda.</p>
<?php else: ?>
<?php if($o['metode']==='transfer'): ?>
<p>Transfer <b><?= rp($o['total']) ?></b> ke:<br><b><?= e($set['bank_nama'] ?? '') ?> <?= e($set['bank_rekening'] ?? '') ?></b><br>a.n. <?= e($set['bank_atas_nama'] ?? '') ?></p>
<?php else: ?>
<p>Scan QRIS berikut dan bayar <b><?= rp($o['total']) ?></b>:</p>
<?php $qrisImg=!empty($set['qris_gambar'])?$set['qris_gambar']:'qris_utama.png'; echo '<img class="q" src="assets/img/'.e($qrisImg).'" alt="QRIS">'; ?>
<?php endif; ?>
<?php if(!empty($set['catatan_bayar'])) echo '<p>'.e($set['catatan_bayar']).'</p>'; ?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="kode" value="<?= e($o['kode']) ?>">
<label>Unggah bukti pembayaran<input type="file" name="bukti" accept="image/jpeg,image/png,image/webp" required></label>
<button class="btn"><?= $o['bukti']?'Ganti bukti':'Kirim bukti' ?></button></form>
<?php endif; ?></div>
<p><a class="btn" href="pesanan.php?kode=<?= e($o['kode']) ?>">Segarkan status</a></p>
<script>setInterval(function(){var f=document.querySelector('input[type=file]');if(!f||!f.value)location.reload()},20000)</script>
<?php endif; ?>
</div></body></html>
