<?php
require __DIR__.'/config.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
function fail($m,$c=400){ http_response_code($c); echo json_encode(['ok'=>false,'error'=>$m]); exit; }
if($_SERVER['REQUEST_METHOD']!=='POST') fail('Metode tidak valid',405);
$in=json_decode(file_get_contents('php://input'),true);
if(!is_array($in)) fail('Data tidak valid');
if(!hash_equals($_SESSION['t'] ?? '',(string)($in['t'] ?? ''))) fail('Sesi habis, silakan muat ulang halaman.');
$nama=trim((string)($in['nama'] ?? '')); $hp=preg_replace('/[^0-9+]/','',(string)($in['hp'] ?? ''));
$tipe=($in['tipe'] ?? '')==='bawa_pulang'?'bawa_pulang':'makan_di_tempat';
$meja=trim((string)($in['meja'] ?? '')); $cat=trim((string)($in['catatan'] ?? ''));
$metode=in_array($in['metode'] ?? '',['tunai','transfer','qris'],true)?$in['metode']:'tunai';
if($nama===''||mb_strlen($nama)>80) fail('Nama wajib diisi (maksimal 80 karakter).');
if(strlen($hp)<8||strlen($hp)>16) fail('Nomor HP tidak valid.');
if($tipe==='makan_di_tempat'&&($meja===''||mb_strlen($meja)>10)) fail('Nomor meja wajib diisi.');
if($tipe==='bawa_pulang') $meja=null;
if(mb_strlen($cat)>255) fail('Catatan terlalu panjang.');
$qty=[];
foreach((is_array($in['items'] ?? null)?$in['items']:[]) as $it){
  $id=(int)($it['id'] ?? 0); $q=(int)($it['q'] ?? 0);
  if($id>0&&$q>0) $qty[$id]=min(50,($qty[$id] ?? 0)+$q);
}
if(!$qty||count($qty)>50) fail('Keranjang kosong.');
$pdo=db();
$st=$pdo->prepare('SELECT id,nama,harga FROM menu WHERE tersedia=1 AND id IN ('.implode(',',array_fill(0,count($qty),'?')).')');
$st->execute(array_keys($qty));
$menu=$st->fetchAll(PDO::FETCH_UNIQUE|PDO::FETCH_ASSOC);
if(count($menu)!==count($qty)) fail('Ada menu yang sudah tidak tersedia. Periksa keranjang Anda.');
$total=0; foreach($qty as $id=>$q) $total+=$menu[$id]['harga']*$q;
try{
  $pdo->beginTransaction();
  $kode='TR'.strtoupper(substr(bin2hex(random_bytes(4)),0,6));
  $pdo->prepare('INSERT INTO pesanan (kode,nama,no_hp,tipe,no_meja,catatan,total,metode) VALUES (?,?,?,?,?,?,?,?)')->execute([$kode,$nama,$hp,$tipe,$meja,$cat?:null,$total,$metode]);
  $pid=(int)$pdo->lastInsertId();
  $ins=$pdo->prepare('INSERT INTO pesanan_item (pesanan_id,menu_id,nama,harga,qty) VALUES (?,?,?,?,?)');
  foreach($qty as $id=>$q) $ins->execute([$pid,$id,$menu[$id]['nama'],$menu[$id]['harga'],$q]);
  $pdo->commit();
}catch(Exception $x){ if($pdo->inTransaction()) $pdo->rollBack(); fail('Gagal menyimpan pesanan. Pastikan tabel pemesanan sudah di-import.',500); }
echo json_encode(['ok'=>true,'kode'=>$kode]);
