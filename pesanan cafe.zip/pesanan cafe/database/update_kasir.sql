-- Jalankan di phpMyAdmin jika database teras_rumah sudah ada.
USE teras_rumah;
CREATE TABLE IF NOT EXISTS kasir (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT IGNORE INTO kasir (username,password,aktif)
VALUES ('kasir','$2y$12$3.TO8LPJWED8.5Gkg0FaauCIj1vrDGt8RUTwzU9dGiawX6oUluq6e',1);
