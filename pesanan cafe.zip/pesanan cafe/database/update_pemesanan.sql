-- Khusus jika database teras_rumah SUDAH di-import sebelumnya.
-- Import file ini untuk menambah tabel pemesanan tanpa menghapus data menu.
USE teras_rumah;

CREATE TABLE IF NOT EXISTS pesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(12) NOT NULL UNIQUE,
  nama VARCHAR(80) NOT NULL,
  no_hp VARCHAR(20) NOT NULL,
  tipe ENUM('makan_di_tempat','bawa_pulang') NOT NULL DEFAULT 'makan_di_tempat',
  no_meja VARCHAR(10) DEFAULT NULL,
  catatan VARCHAR(255) DEFAULT NULL,
  total INT NOT NULL DEFAULT 0,
  metode ENUM('tunai','transfer','qris') NOT NULL DEFAULT 'tunai',
  status_bayar ENUM('belum','menunggu_verifikasi','lunas') NOT NULL DEFAULT 'belum',
  status ENUM('baru','diproses','siap','selesai','dibatalkan') NOT NULL DEFAULT 'baru',
  bukti VARCHAR(120) DEFAULT NULL,
  dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS pesanan_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pesanan_id INT NOT NULL,
  menu_id INT DEFAULT NULL,
  nama VARCHAR(100) NOT NULL,
  harga INT NOT NULL,
  qty INT NOT NULL,
  FOREIGN KEY (pesanan_id) REFERENCES pesanan(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS pengaturan (
  kunci VARCHAR(40) PRIMARY KEY,
  nilai TEXT
) ENGINE=InnoDB;
INSERT IGNORE INTO pengaturan (kunci,nilai) VALUES
('bank_nama','BSI'),('bank_rekening','0000000000'),('bank_atas_nama','Teras Rumah'),('qris_gambar','qris_utama.png'),('catatan_bayar','');
