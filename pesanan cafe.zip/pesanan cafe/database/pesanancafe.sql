-- Import file ini lewat phpMyAdmin (tab Import)
CREATE DATABASE IF NOT EXISTS teras_rumah CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE teras_rumah;
DROP TABLE IF EXISTS menu;
DROP TABLE IF EXISTS admin;
CREATE TABLE menu (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  kategori ENUM('makanan','minuman') NOT NULL,
  harga INT NOT NULL DEFAULT 0,
  deskripsi TEXT,
  gambar VARCHAR(120) NOT NULL,
  tersedia TINYINT(1) NOT NULL DEFAULT 1,
  favorit TINYINT(1) NOT NULL DEFAULT 0,
  dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
INSERT INTO admin (username,password) VALUES ('admin','$2y$10$bbZdMyZsCZABvYSYVZAdx.Jh1aUD0qPob0t115S1xmfxkzc.9a97W');
INSERT INTO menu (nama,kategori,harga,deskripsi,gambar,tersedia,favorit) VALUES
('Nasi Ayam Pecak','makanan',28000,'Ayam goreng dengan sambal pecak tomat dan cabai, disajikan dengan nasi, tempe, kol, dan timun.','nasipecak.jpg',1,1),
('Paket Nasi Ayam','makanan',25000,'Paket nasi dengan pilihan ayam bakar, pecak, penyet, atau geprek.','paket.jpg',1,0),
('Mie Aceh Udang','makanan',32000,'Mie Aceh berbumbu rempah dengan udang, taburan bawang goreng, dan kerupuk.','mie.jpg',1,0),
('Ramen Spicy','makanan',30000,'Ramen berkuah pedas dengan telur setengah matang.','ramen.jpg',1,0),
('Chicken Katsu Kari Ramen','makanan',35000,'Ramen kuah kari dengan chicken katsu renyah, telur, nori, dan daun bawang.','katsu.jpg',1,1),
('Nasi Cumi Udang Saus','makanan',35000,'Nasi putih dengan cumi dan udang dalam saus pedas gurih.','cumiudang.jpg',1,0),
('Nasi Udang Crispy','makanan',33000,'Udang goreng tepung dengan nasi, taburan bawang goreng, timun, dan sambal.','udangcrispy.jpg',1,0),
('Nasi Serundeng','makanan',27000,'Nasi di atas daun pisang dengan serundeng gurih, kerupuk, dan timun.','serundeng.jpg',1,0),
('Cah Kangkung / Cah Toge','makanan',15000,'Tumisan sayur tambahan untuk menemani nasi.','kangkung.jpg',1,0),
('Tempe Mendoan','makanan',15000,'Tempe tipis berbalut tepung berbumbu, digoreng setengah matang, dengan kecap pedas.','mendoan.jpg',1,0),
('Tahu Cabe Garam','makanan',17000,'Tahu goreng renyah dengan taburan cabai, bawang, dan garam.','tahu.jpg',1,0),
('Cemilan Bersama','makanan',30000,'Kentang goreng, sosis, dan nugget dengan saus sambal. Cocok untuk dinikmati ramai-ramai.','cemilan.jpg',1,0),
('Pizza Keju','makanan',32000,'Pizza tipis dengan keju mozzarella leleh dan taburan oregano.','pizza.jpg',1,0),
('Churros','makanan',20000,'Churros goreng renyah bertabur gula, dengan saus cokelat.','churros.jpg',1,0),
('Teras Creamy Coffee','minuman',22000,'Kopi susu dingin lembut dengan lapisan karamel di dasar gelas.','creamy.jpg',1,0),
('Kopi Coklat','minuman',23000,'Kopi susu dingin dengan saus cokelat di dasar gelas.','kopicoklat.jpg',1,0),
('Teras Korean Strawberry Milk','minuman',25000,'Susu dingin dengan saus stroberi dan potongan buah.','strawberry.jpg',1,0),
('Ice Caramel','minuman',24000,'Minuman susu dingin dengan siraman saus karamel.','caramel.jpg',1,0),
('Teras Tropical','minuman',23000,'Espresso dituang ke atas soda dan es untuk rasa kopi yang segar.','tropical.jpg',1,1),
('Fresh Blues Soda','minuman',21000,'Soda berlapis biru dan merah dengan biji selasih serta irisan lemon.','blues.jpg',1,0),
('Mango Yakult','minuman',20000,'Minuman segar rasa mangga dengan Yakult.','mango.jpg',1,0),
('Strawberry Yakult','minuman',20000,'Minuman segar rasa stroberi dengan Yakult.','strawb.jpg',1,0),
('Lychee Tea','minuman',18000,'Teh dingin dengan buah leci.','lychee.jpg',1,0),
('Peach Tea','minuman',18000,'Teh dingin dengan potongan buah persik.','peach.jpg',1,0),
('Ice Tea / Lemon Tea','minuman',12000,'Teh dingin klasik, tersedia versi biasa atau lemon.','icetea.jpg',1,0),
('Coco Mango','minuman',20000,'Minuman mangga dengan kelapa muda dan biji selasih.','coco.jpg',1,0),
('Easy Peachy','minuman',20000,'Soda persik dengan biji selasih.','peachy.jpg',1,0),
('Blast Berry','minuman',20000,'Minuman berry merah dengan potongan stroberi dan biji selasih.','blast.jpg',1,0);

CREATE TABLE IF NOT EXISTS pesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(12) NOT NULL UNIQUE,
  nama VARCHAR(80) NOT NULL,
  no_hp VARCHAR(20) NOT NULL,
  tipe ENUM('makan_di_tempat','bawa_pulang') NOT NULL DEFAULT 'makan_di_tempat',
  no_meja VARCHAR(10) DEFAULT NULL,
  catatan VARCHAR(255) DEFAULT NULL,
  total INT NOT NULL DEFAULT 0,
  metode ENUM('tunai','transfer','qris') NOT NULL DEFAULT 'tunai',
  status_bayar ENUM('belum','menunggu_verifikasi','lunas') NOT NULL DEFAULT 'belum',
  status ENUM('baru','diproses','siap','selesai','dibatalkan') NOT NULL DEFAULT 'baru',
  bukti VARCHAR(120) DEFAULT NULL,
  dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS pesanan_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pesanan_id INT NOT NULL,
  menu_id INT DEFAULT NULL,
  nama VARCHAR(100) NOT NULL,
  harga INT NOT NULL,
  qty INT NOT NULL,
  FOREIGN KEY (pesanan_id) REFERENCES pesanan(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS pengaturan (
  kunci VARCHAR(40) PRIMARY KEY,
  nilai TEXT
) ENGINE=InnoDB;
INSERT IGNORE INTO pengaturan (kunci,nilai) VALUES
('bank_nama','BSI'),('bank_rekening','0000000000'),('bank_atas_nama','Teras Rumah'),('qris_gambar','qris_utama.png'),('catatan_bayar','');


-- Akun khusus kasir untuk verifikasi pembayaran dan pengelolaan pesanan
CREATE TABLE IF NOT EXISTS kasir (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT IGNORE INTO kasir (username,password,aktif)
VALUES ('kasir','$2y$12$3.TO8LPJWED8.5Gkg0FaauCIj1vrDGt8RUTwzU9dGiawX6oUluq6e',1);
