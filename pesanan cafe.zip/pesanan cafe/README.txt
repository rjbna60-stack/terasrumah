MENU RESTORAN DIGITAL - TERAS RUMAH (PHP + MySQL, XAMPP)

CARA PASANG
1. Ekstrak folder "teras-rumah" ke C:\xampp\htdocs\
2. Buka XAMPP Control Panel, Start "Apache" dan "MySQL".
3. Buka http://localhost/phpmyadmin -> tab "Import" -> pilih file
   teras-rumah\database\teras_rumah.sql -> klik "Import" (database teras_rumah dibuat otomatis).
4. Buka website:  http://localhost/teras-rumah/
5. Buka admin:    http://localhost/teras-rumah/admin/login.php
   Username: admin    Password: admin123
6. Buka kasir:    http://localhost/teras-rumah/kasir/login.php
   Username: kasir    Password: kasir123 (ganti password demo sebelum dipakai sungguhan)

CATATAN
- Pengaturan database ada di config.php (default XAMPP: user root, password kosong).
- Admin bisa tambah, ubah, hapus menu, upload foto, sembunyikan menu, dan atur menu andalan.
- Harga pada data awal hanyalah contoh. Ubah lewat halaman admin.
- Ganti password admin: di phpMyAdmin buka tabel admin, atau jalankan di tab SQL:
  UPDATE admin SET password = '<hash baru>' WHERE username='admin';
  (hash dibuat dengan fungsi PHP password_hash).

STRUKTUR
index.php          halaman website pelanggan (data dari MySQL)
config.php         koneksi database
admin/             login & pengelolaan menu (CRUD)
assets/img/        foto menu dan suasana
database/          file SQL untuk phpMyAdmin

FITUR PEMESANAN & PEMBAYARAN
- Pelanggan: pilih menu -> "Tambah ke keranjang" -> menu Keranjang -> isi data -> "Pesan sekarang".
  Setelah itu pelanggan mendapat kode pesanan dan halaman status (pesanan.php).
- Metode bayar: Tunai di kasir, Transfer bank, QRIS. Untuk transfer/QRIS pelanggan mengunggah bukti bayar.
- Kasir: http://localhost/teras-rumah/kasir/login.php (login terpisah untuk melihat pesanan, memeriksa bukti transfer/QRIS, menandai pembayaran lunas, dan memperbarui status pesanan).
- Admin: http://localhost/teras-rumah/admin/pesanan.php (pengelolaan pesanan lengkap, termasuk pembatalan).
- Admin: menu "Pembayaran" untuk mengisi nomor rekening dan mengunggah gambar QRIS.
- Harga selalu dihitung ulang di server dari database, bukan dari browser.
- Pembayaran diverifikasi manual oleh admin (belum memakai payment gateway otomatis seperti Midtrans).

JIKA DATABASE SUDAH DI-IMPORT SEBELUMNYA
Import file database\update_pemesanan.sql lewat phpMyAdmin (menu dan data lama tidak dihapus).
Jika baru pertama kali pasang, cukup import database\teras_rumah.sql.

FITUR KASIR BARU
- Login khusus kasir di /kasir/login.php.
- Panel kasir menampilkan pesanan, rincian item, total, metode bayar, bukti transfer/QRIS, status pesanan, dan ringkasan omzet.
- Untuk database yang sudah ada, import database/update_kasir.sql lewat phpMyAdmin. Untuk instalasi baru, import database/teras_rumah.sql seperti biasa.
