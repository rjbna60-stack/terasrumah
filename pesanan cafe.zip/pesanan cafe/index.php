<?php
require __DIR__.'/config.php';
session_start(); if(empty($_SESSION['t'])) $_SESSION['t']=bin2hex(random_bytes(16));
$rows=db()->query("SELECT id,nama,kategori,harga,deskripsi,gambar,favorit FROM menu WHERE tersedia=1 ORDER BY FIELD(kategori,'makanan','minuman'), id")->fetchAll();
$M=array_map(function($r){return ['id'=>(string)$r['id'],'n'=>e($r['nama']),'c'=>$r['kategori'],'p'=>(int)$r['harga'],'d'=>e($r['deskripsi']),'g'=>'assets/img/'.$r['gambar'],'f'=>(int)$r['favorit']];},$rows);
$json=json_encode($M,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Menu Digital Teras Rumah Cafe &amp; Resto</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#fbfaf6;--card:#fff;--ink:#26332b;--muted:#6a766d;--line:#e3e6dc;--green:#6f9d84;--gold:#c8923b;--soft:#e8f0ea;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#17201b;--card:#1f2b24;--ink:#eef1e9;--muted:#a3b0a6;--line:#2f3d34;--soft:#243329}}
:root[data-theme="dark"]{--bg:#17201b;--card:#1f2b24;--ink:#eef1e9;--muted:#a3b0a6;--line:#2f3d34;--soft:#243329}
html{scroll-padding-top:env(safe-area-inset-top,0px);scroll-behavior:smooth}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:400 16px/1.6 'Nunito Sans',system-ui,sans-serif}
h1,h2,h3{font-family:'Fraunces',Georgia,serif;line-height:1.15;margin:0}
img{max-width:100%;display:block}
a{color:inherit}
:focus-visible{outline:3px solid var(--gold);outline-offset:2px}
header.nav{position:sticky;top:env(safe-area-inset-top,0px);z-index:20;background:var(--bg);border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 20px;flex-wrap:wrap}
.brand{font-family:'Fraunces',serif;font-weight:700;font-size:20px;text-decoration:none}
nav{display:flex;gap:4px;flex-wrap:wrap}
nav a{text-decoration:none;padding:7px 14px;border-radius:99px;font-weight:600;font-size:15px;color:var(--muted)}
nav a.on{background:var(--soft);color:var(--ink)}
main{max-width:1080px;margin:0 auto;padding:0 20px 60px}
.view{display:none}.view.on{display:block}
.hero{display:grid;grid-template-columns:1.05fr 1fr;gap:36px;align-items:center;padding:36px 0 24px}
.hero h1{font-size:clamp(34px,5.4vw,56px);font-weight:700}
.hero p{color:var(--muted);max-width:46ch;margin:16px 0 24px}
.hero img{border-radius:28px 28px 120px 28px;aspect-ratio:4/4.2;object-fit:cover;width:100%}
.btn{display:inline-block;background:var(--green);color:#10201a;font-weight:700;border:0;border-radius:12px;padding:12px 22px;text-decoration:none;cursor:pointer;font:inherit;font-weight:700}
.btn.alt{background:transparent;border:1.5px solid var(--green);color:var(--ink);margin-left:8px}
.cats{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:28px 0}
.cat{position:relative;border-radius:22px;overflow:hidden;aspect-ratio:16/10;display:block;text-decoration:none;color:#fff}
.cat img{width:100%;height:100%;object-fit:cover}
.cat span{position:absolute;inset:auto 0 0 0;padding:44px 20px 16px;background:linear-gradient(transparent,rgba(10,25,18,.78));font:700 24px 'Fraunces',serif}
.cat small{display:block;font:600 14px 'Nunito Sans',sans-serif;opacity:.9}
h2.t{font-size:clamp(26px,3.6vw,36px);margin:36px 0 6px}
.sub{color:var(--muted);margin:0 0 20px}
.tabs{display:flex;gap:8px;margin:8px 0 22px;flex-wrap:wrap}
.tabs button{font:600 15px 'Nunito Sans',sans-serif;border:1.5px solid var(--line);background:var(--card);color:var(--ink);padding:9px 18px;border-radius:99px;cursor:pointer}
.tabs button.on{background:var(--green);border-color:var(--green);color:#10201a}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:18px;overflow:hidden;cursor:pointer;text-align:left;padding:0;font:inherit;color:inherit;display:block;width:100%}
.card:hover{border-color:var(--green)}
.card img{aspect-ratio:1/1;width:100%;object-fit:cover}
.card div{padding:14px 16px 16px}
.card h3{font-size:19px}
.card p{margin:4px 0 0;color:var(--muted);font-size:14px}
.price{font-weight:700;color:var(--gold);margin-top:8px;display:block}
.detail{display:grid;grid-template-columns:1fr 1fr;gap:34px;align-items:start;padding-top:24px}
.detail img{border-radius:24px;width:100%;aspect-ratio:1/1;object-fit:cover}
.detail h1{font-size:clamp(30px,4.4vw,46px)}
.chip{display:inline-block;background:var(--soft);padding:3px 12px;border-radius:99px;font-size:14px;font-weight:600;margin-bottom:12px}
.detail .p{font:700 28px 'Fraunces',serif;color:var(--gold);margin:16px 0}
.back{background:none;border:0;color:var(--muted);font:600 15px 'Nunito Sans',sans-serif;cursor:pointer;padding:8px 0}
.gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px;margin:18px 0 32px}
.gal img{border-radius:14px;aspect-ratio:1/1;object-fit:cover;width:100%}
.info{display:grid;grid-template-columns:1fr 1fr;gap:28px;align-items:center;margin-top:20px}
.info img{border-radius:24px;width:100%;aspect-ratio:3/4;object-fit:cover;max-height:520px}
.box{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px 20px;margin:12px 0}
footer{border-top:1px solid var(--line);text-align:center;color:var(--muted);padding:22px 20px;font-size:14px}
@media(max-width:760px){.hero,.detail,.info{grid-template-columns:1fr}.hero img{aspect-ratio:4/3}.cats{grid-template-columns:1fr}.grid{grid-template-columns:1fr 1fr;gap:12px}.card h3{font-size:16px}}
@media(max-width:380px){.grid{grid-template-columns:1fr}}

.co{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:6px 20px 20px;margin:16px 0;max-width:560px}
.co h3{font-size:19px;margin:16px 0 4px}.co label{display:block;font-weight:600;margin:10px 0 0}
.co input:not([type=radio]){display:block;width:100%;margin-top:4px;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--bg);color:var(--ink);font:inherit}
.opts{display:flex;gap:6px 18px;flex-wrap:wrap}.opts label{font-weight:400}
.cr{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px;margin:10px 0;max-width:560px}
.cr img{width:60px;height:60px;border-radius:10px;object-fit:cover}.ci{flex:1;display:flex;flex-direction:column}.ci span{color:var(--gold);font-weight:700}
.qty{display:flex;align-items:center;gap:10px;margin:10px 0}.qb{width:34px;height:34px;border-radius:50%;border:1.5px solid var(--green);background:transparent;color:var(--ink);font-size:18px;cursor:pointer}
.x{background:none;border:0;color:var(--muted);font-size:22px;cursor:pointer}.tot{display:flex;justify-content:space-between;max-width:560px;font-size:20px;padding:6px 4px}
.cerr{color:#c0392b;font-weight:600;min-height:1em}#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:var(--ink);color:var(--bg);padding:10px 20px;border-radius:99px;opacity:0;transition:opacity .25s;pointer-events:none;z-index:50}#toast.on{opacity:1}
</style>
</head>
<body>
<header class="nav">
<a class="brand" href="#beranda">Teras Rumah</a>
<nav aria-label="Navigasi utama">
<a href="#beranda" data-v="beranda">Beranda</a>
<a href="#menu" data-v="menu">Menu</a>
<a href="#info" data-v="info">Informasi</a>
<a href="#keranjang" data-v="keranjang">Keranjang <span id="cc"></span></a>
</nav>
</header>
<main>

<section class="view" id="v-beranda">
<div class="hero">
<div>
<h1>Menu Teras Rumah, langsung dari ponsel Anda</h1>
<p>Lihat makanan dan minuman lengkap dengan foto, deskripsi, dan harga. Pilih kategori, ketuk menu, dan baca detailnya tanpa menu cetak.</p>
<a class="btn" href="#menu">Lihat menu</a><a class="btn alt" href="#info">Tentang kafe</a>
</div>
<img src="assets/img/depan.jpg" alt="Bangunan Teras Rumah Cafe &amp; Resto">
</div>
<h2 class="t">Pilih kategori</h2>
<div class="cats">
<a class="cat" href="#menu/makanan"><img src="assets/img/nasipecak.jpg" alt="Ayam pecak"><span>Makanan<small id="nF"></small></span></a>
<a class="cat" href="#menu/minuman"><img src="assets/img/tropical.jpg" alt="Teras Tropical"><span>Minuman<small id="nD"></small></span></a>
</div>
<h2 class="t">Menu andalan</h2>
<p class="sub">Tiga pilihan yang paling sering dipesan.</p>
<div class="grid" id="fav"></div>
</section>

<section class="view" id="v-menu">
<h2 class="t">Daftar menu</h2>
<p class="sub">Ketuk salah satu menu untuk melihat detailnya.</p>
<div class="tabs" role="tablist">
<button data-c="semua">Semua</button><button data-c="makanan">Makanan</button><button data-c="minuman">Minuman</button>
</div>
<div class="grid" id="list"></div>
</section>

<section class="view" id="v-detail">
<button class="back" id="back">&larr; Kembali ke daftar menu</button>
<div class="detail" id="det"></div>
</section>

<section class="view" id="v-info">
<h2 class="t">Informasi restoran</h2>
<p class="sub">Teras Rumah Cafe &amp; Resto, tempat santai dengan bangunan putih, kusen kayu, dan taman batu kerikil.</p>
<div class="info">
<img src="assets/img/vert.jpg" alt="Tampak depan Teras Rumah">
<div>
<div class="box"><strong>Konsep tempat</strong><br>Bangunan rumah bergaya minimalis dengan area duduk dalam ruangan, teras, dan taman terbuka.</div>
<div class="box"><strong>Menu</strong><br>Kopi, minuman segar, makanan berat, dan camilan.</div>
<div class="box"><strong>Instagram</strong><br><a href="https://www.instagram.com/terasrumahh.id" target="_blank" rel="noopener">@terasrumahh.id</a></div>
<div class="box"><strong>Alamat dan jam buka</strong><br>Jl. Laksamana Malahayati No. 44 (di sebelah Outfix Butik), Pulo Kiton, Kota Juang, Bireuen, Aceh, Jam Operasional Setiap hari pukul 15.00 – 00.00 WIB.</div>
</div>
</div>
<h2 class="t">Galeri</h2>
<div class="gal" id="gal"></div>
</section>

<section class="view" id="v-keranjang">
<h2 class="t">Keranjang &amp; pemesanan</h2>
<div id="cl"></div>
<form id="co" class="co" novalidate style="display:none">
<h3>Data pemesan</h3>
<label>Nama<input id="f-nama" maxlength="80" autocomplete="name"></label>
<label>Nomor HP / WhatsApp<input id="f-hp" inputmode="tel" maxlength="16" autocomplete="tel"></label>
<div class="opts"><label><input type="radio" name="tipe" value="makan_di_tempat" checked> Makan di tempat</label><label><input type="radio" name="tipe" value="bawa_pulang"> Bawa pulang</label></div>
<label id="l-meja">Nomor meja<input id="f-meja" maxlength="10"></label>
<h3>Metode pembayaran</h3>
<div class="opts"><label><input type="radio" name="metode" value="tunai" checked> Tunai di kasir</label><label><input type="radio" name="metode" value="transfer"> Transfer bank</label><label><input type="radio" name="metode" value="qris"> QRIS</label></div>
<label>Catatan (opsional)<input id="f-cat" maxlength="255"></label>
<p id="cerr" class="cerr" role="alert"></p>
<button class="btn" id="go" type="submit">Pesan sekarang</button>
</form>
<form class="co" action="pesanan.php" method="get"><h3>Sudah memesan?</h3><label>Kode pesanan<input name="kode" required></label><button class="btn alt" style="margin:0">Cek pesanan</button></form>
</section>
</main>
<footer>Menu Restoran Digital Interaktif Berbasis Web &middot; Proyek PBL TRMM Politeknik Negeri Lhokseumawe 2026 &middot; <a href="admin/login.php">Admin</a> · <a href="kasir/login.php">Kasir</a></footer>
<div id="toast" role="status"></div>

<script>
var TOKEN=<?= json_encode($_SESSION['t']) ?>;
var M=<?= $json ?>;
var rp=function(x){return 'Rp '+x.toLocaleString('id-ID')};
var $=function(s){return document.querySelector(s)};
var esc=function(s){return s.replace(/&/g,'&amp;')};
function card(m){return '<button class="card" data-id="'+m.id+'"><img src="'+m.g+'" alt="'+m.n+'" loading="lazy"><div><h3>'+m.n+'</h3><p>'+(m.c==='makanan'?'Makanan':'Minuman')+'</p><span class="price">'+rp(m.p)+'</span></div></button>'}
function fill(el,arr){el.innerHTML=arr.map(card).join('')}
$('#nF').textContent=M.filter(function(m){return m.c==='makanan'}).length+' menu';
$('#nD').textContent=M.filter(function(m){return m.c==='minuman'}).length+' menu';
fill($('#fav'),M.filter(function(m){return m.f==1}).slice(0,3));
$('#gal').innerHTML=['teras','hijau','jendela','taman','rotan','mesin','bangku','barista','tamp','depan'].map(function(k){return '<img src="'+'assets/img/'+k+'.jpg'+'" alt="Suasana Teras Rumah" loading="lazy">'}).join('');
var cat='semua',last='#menu';
function show(v){document.querySelectorAll('.view').forEach(function(e){e.classList.toggle('on',e.id==='v-'+v)});document.querySelectorAll('nav a').forEach(function(a){a.classList.toggle('on',a.dataset.v===(v==='detail'?'menu':v))});window.scrollTo(0,0)}
function setCat(c){cat=c;document.querySelectorAll('.tabs button').forEach(function(b){b.classList.toggle('on',b.dataset.c===c)});fill($('#list'),M.filter(function(m){return c==='semua'||m.c===c}))}
function route(){
var h=location.hash.replace('#','')||'beranda',p=h.split('/');
if(p[0]==='menu'){setCat(p[1]||'semua');last=location.hash||'#menu';show('menu')}
else if(p[0]==='item'){var m=M.filter(function(x){return x.id===p[1]})[0];if(!m){location.hash='#menu';return}
$('#det').innerHTML='<img src="'+m.g+'" alt="'+m.n+'"><div><span class="chip">'+(m.c==='makanan'?'Makanan':'Minuman')+'</span><h1>'+m.n+'</h1><div class="p">'+rp(m.p)+'</div><p>'+m.d+'</p><div class="qty"><button type="button" class="qb" data-act="dm" aria-label="Kurangi">&minus;</button><b id="dq">1</b><button type="button" class="qb" data-act="dp" aria-label="Tambah">+</button></div><button type="button" class="btn" data-act="add" data-id="'+m.id+'">Tambah ke keranjang</button><a class="btn alt" href="'+last+'">Menu lainnya</a></div>';show('detail')}
else if(p[0]==='keranjang'){renderCart();show('keranjang')}
else if(p[0]==='info')show('info');
else show('beranda')}
document.addEventListener('click',function(e){var c=e.target.closest('.card');if(c){location.hash='#item/'+c.dataset.id}var t=e.target.closest('.tabs button');if(t){location.hash='#menu/'+t.dataset.c}});
$('#back').onclick=function(){location.hash=last};
var CART={};try{CART=JSON.parse(localStorage.getItem('tr_cart')||'{}')}catch(e){}
function find(id){return M.filter(function(m){return m.id===String(id)})[0]}
function cc(){var n=0;for(var k in CART)n+=CART[k];$('#cc').textContent=n?'('+n+')':''}
function saveCart(){try{localStorage.setItem('tr_cart',JSON.stringify(CART))}catch(e){}cc()}
function toast(t){var el=$('#toast');el.textContent=t;el.classList.add('on');setTimeout(function(){el.classList.remove('on')},1800)}
function renderCart(){
Object.keys(CART).forEach(function(k){if(!find(k))delete CART[k]});
var ids=Object.keys(CART),tot=0,h='';
ids.forEach(function(k){var m=find(k),q=CART[k];tot+=m.p*q;h+='<div class="cr"><img src="'+m.g+'" alt=""><div class="ci"><b>'+m.n+'</b><span>'+rp(m.p)+'</span></div><div class="qty"><button type="button" class="qb" data-act="min" data-id="'+k+'" aria-label="Kurangi">&minus;</button><b>'+q+'</b><button type="button" class="qb" data-act="plus" data-id="'+k+'" aria-label="Tambah">+</button></div><button type="button" class="x" data-act="del" data-id="'+k+'" aria-label="Hapus">&times;</button></div>'});
$('#cl').innerHTML=ids.length?h+'<div class="tot"><span>Total</span><b>'+rp(tot)+'</b></div>':'<p class="sub">Keranjang masih kosong. <a href="#menu">Lihat menu</a></p>';
$('#co').style.display=ids.length?'block':'none';saveCart()}
function mejaToggle(){$('#l-meja').style.display=document.querySelector('input[name=tipe]:checked').value==='bawa_pulang'?'none':'block'}
document.querySelectorAll('input[name=tipe]').forEach(function(r){r.onchange=mejaToggle});mejaToggle();
document.addEventListener('click',function(e){var b=e.target.closest('[data-act]');if(!b)return;var a=b.dataset.act,id=b.dataset.id,dq=$('#dq');
if(a==='dp')dq.textContent=Math.min(50,+dq.textContent+1);
else if(a==='dm')dq.textContent=Math.max(1,+dq.textContent-1);
else if(a==='add'){CART[id]=Math.min(50,(CART[id]||0)+(+dq.textContent));saveCart();toast('Ditambahkan ke keranjang')}
else if(a==='plus'){CART[id]=Math.min(50,CART[id]+1);renderCart()}
else if(a==='min'){CART[id]--;if(CART[id]<1)delete CART[id];renderCart()}
else if(a==='del'){delete CART[id];renderCart()}});
$('#co').addEventListener('submit',function(e){e.preventDefault();
var er=$('#cerr'),b=$('#go');er.textContent='';
var items=Object.keys(CART).map(function(k){return{id:+k,q:CART[k]}});if(!items.length)return;
b.disabled=true;b.textContent='Mengirim...';
function reset(m){er.textContent=m;b.disabled=false;b.textContent='Pesan sekarang'}
fetch('pesan.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({t:TOKEN,nama:$('#f-nama').value,hp:$('#f-hp').value,tipe:document.querySelector('input[name=tipe]:checked').value,meja:$('#f-meja').value,catatan:$('#f-cat').value,metode:document.querySelector('input[name=metode]:checked').value,items:items})})
.then(function(r){return r.json()}).then(function(d){if(d.ok){CART={};saveCart();location.href='pesanan.php?kode='+d.kode}else reset(d.error)}).catch(function(){reset('Gagal terhubung ke server.')})});
cc();
window.addEventListener('hashchange',route);route();
</script>
</body>
</html>
