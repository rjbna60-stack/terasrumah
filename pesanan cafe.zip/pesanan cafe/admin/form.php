<?php
require __DIR__.'/auth.php'; need_login();
$id=(int)($_GET['id'] ?? 0); $err='';
$row=['nama'=>'','kategori'=>'makanan','harga'=>'','deskripsi'=>'','gambar'=>'','tersedia'=>1,'favorit'=>0];
if($id){ $s=db()->prepare('SELECT * FROM menu WHERE id=?'); $s->execute([$id]); $row=$s->fetch() ?: exit('Menu tidak ditemukan'); }
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_ok()) $err='Sesi tidak valid, coba lagi.';
  $nama=trim($_POST['nama'] ?? ''); $kat=($_POST['kategori'] ?? '')==='minuman'?'minuman':'makanan';
  $harga=max(0,(int)($_POST['harga'] ?? 0)); $des=trim($_POST['deskripsi'] ?? '');
  $tersedia=isset($_POST['tersedia'])?1:0; $fav=isset($_POST['favorit'])?1:0; $gambar=$row['gambar'];
  if(!$err && $nama==='') $err='Nama menu wajib diisi.';
  $f=$_FILES['gambar'] ?? null;
  if(!$err && $f && $f['error']===UPLOAD_ERR_OK){
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime] ?? null;
    if(!$ext) $err='Foto harus JPG, PNG, atau WEBP.';
    elseif($f['size']>3*1024*1024) $err='Ukuran foto maksimal 3 MB.';
    else{
      $new='menu_'.bin2hex(random_bytes(6)).'.'.$ext;
      if(move_uploaded_file($f['tmp_name'],__DIR__.'/../assets/img/'.$new)){
        if($gambar && strpos($gambar,'menu_')===0) @unlink(__DIR__.'/../assets/img/'.$gambar);
        $gambar=$new;
      } else $err='Gagal menyimpan foto.';
    }
  }
  if(!$err && $gambar==='') $err='Foto menu wajib diisi.';
  if(!$err){
    if($id) db()->prepare('UPDATE menu SET nama=?,kategori=?,harga=?,deskripsi=?,gambar=?,tersedia=?,favorit=? WHERE id=?')->execute([$nama,$kat,$harga,$des,$gambar,$tersedia,$fav,$id]);
    else db()->prepare('INSERT INTO menu (nama,kategori,harga,deskripsi,gambar,tersedia,favorit) VALUES (?,?,?,?,?,?,?)')->execute([$nama,$kat,$harga,$des,$gambar,$tersedia,$fav]);
    header('Location: index.php?ok=1'); exit;
  }
  $row=['nama'=>$nama,'kategori'=>$kat,'harga'=>$harga,'deskripsi'=>$des,'gambar'=>$gambar,'tersedia'=>$tersedia,'favorit'=>$fav];
}
top($id?'Edit menu':'Tambah menu');
?>
<h1><?= $id?'Edit menu':'Tambah menu' ?></h1>
<?php if($err) echo '<div class="err">'.e($err).'</div>'; ?>
<form class="f" method="post" enctype="multipart/form-data">
<input type="hidden" name="t" value="<?= e(csrf()) ?>">
<label>Nama menu</label><input type="text" name="nama" value="<?= e($row['nama']) ?>" required>
<label>Kategori</label><select name="kategori"><option value="makanan" <?= $row['kategori']==='makanan'?'selected':'' ?>>Makanan</option><option value="minuman" <?= $row['kategori']==='minuman'?'selected':'' ?>>Minuman</option></select>
<label>Harga (Rp)</label><input type="number" name="harga" min="0" step="500" value="<?= e($row['harga']) ?>" required>
<label>Deskripsi</label><textarea name="deskripsi" rows="4"><?= e($row['deskripsi']) ?></textarea>
<label>Foto <?= $id?'(kosongkan jika tidak diganti)':'' ?></label>
<?php if($row['gambar']) echo '<img class="t" src="../assets/img/'.e($row['gambar']).'" alt=""><br>'; ?>
<input type="file" name="gambar" accept="image/jpeg,image/png,image/webp">
<label><input type="checkbox" name="tersedia" <?= $row['tersedia']?'checked':'' ?>> Tampilkan di website</label>
<label><input type="checkbox" name="favorit" <?= $row['favorit']?'checked':'' ?>> Menu andalan di beranda (maks. 3 pertama yang tampil)</label>
<p><button class="btn">Simpan</button> <a class="btn g" href="index.php">Batal</a></p>
</form>
<?php bottom();
