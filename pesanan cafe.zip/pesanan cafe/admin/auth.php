<?php
require __DIR__.'/../config.php';
session_start();
function need_login(){ if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; } }
function csrf(){ if(empty($_SESSION['t'])) $_SESSION['t']=bin2hex(random_bytes(16)); return $_SESSION['t']; }
function csrf_ok(){ return isset($_POST['t']) && hash_equals($_SESSION['t'] ?? '', $_POST['t']); }
function top($t){ echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($t).' - Admin Teras Rumah</title><style>
body{margin:0;background:#f5f4ee;color:#26332b;font:16px/1.5 system-ui,sans-serif}.w{max-width:960px;margin:0 auto;padding:20px}
h1{font-size:24px;margin:0 0 16px}a{color:#3f7a5c}.bar{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:16px}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}th,td{padding:10px 12px;border-bottom:1px solid #e6e8df;text-align:left;font-size:15px;vertical-align:middle}
img.t{width:56px;height:56px;object-fit:cover;border-radius:8px}.btn{display:inline-block;background:#6f9d84;color:#10201a;border:0;border-radius:8px;padding:8px 14px;font:600 14px system-ui;text-decoration:none;cursor:pointer}
.btn.r{background:#d9534f;color:#fff}.btn.g{background:#e3e6dc}form.f{background:#fff;padding:20px;border-radius:12px;max-width:560px}
label{display:block;font-weight:600;margin:12px 0 4px}input[type=text],input[type=number],input[type=password],select,textarea{width:100%;padding:9px 10px;border:1px solid #cfd5c8;border-radius:8px;font:inherit}
.err{background:#fde8e7;color:#8a1f1a;padding:10px 14px;border-radius:8px;margin-bottom:12px}.ok{background:#e4f2e9;padding:10px 14px;border-radius:8px;margin-bottom:12px}.wrap{overflow-x:auto}.nav{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.nav a{background:#fff;padding:7px 14px;border-radius:99px;text-decoration:none;font-weight:600;font-size:14px}.bd{background:#d9534f;color:#fff;border-radius:99px;padding:0 7px;font-size:12px}.pill{display:inline-block;padding:2px 10px;border-radius:99px;background:#e3e6dc;font-size:13px;font-weight:600}.pill.ok{background:#bfe3cd}.pill.w{background:#fbe3a8}.pill.bad{background:#f3c9c6}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:700px){.grid2{grid-template-columns:1fr}}
</style></head><body><div class="w">'; nav(); }
function bottom(){ echo '</div></body></html>'; }
function nav(){
  if(empty($_SESSION['admin'])) return;
  try{ $n=(int)db()->query("SELECT COUNT(*) FROM pesanan WHERE status='baru'")->fetchColumn(); }catch(Exception $x){ $n=0; }
  echo '<div class="nav"><a href="index.php">Menu</a><a href="pesanan.php">Pesanan'.($n?' <b class="bd">'.$n.'</b>':'').'</a><a href="pengaturan.php">Pembayaran</a><a href="../index.php" target="_blank">Website</a><a href="logout.php">Keluar</a></div>';
}
function pill($t,$cls=''){ return '<span class="pill '.$cls.'">'.e($t).'</span>'; }
function pill_bayar($s){ return pill(SB[$s],$s==='lunas'?'ok':($s==='menunggu_verifikasi'?'w':'')); }
function pill_status($s){ return pill(SS[$s],$s==='selesai'?'ok':($s==='dibatalkan'?'bad':($s==='baru'?'w':''))); }
