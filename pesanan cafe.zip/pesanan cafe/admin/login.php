<?php
require __DIR__.'/auth.php';
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_ok()) $err='Sesi tidak valid, coba lagi.';
  else{
    $s=db()->prepare('SELECT * FROM admin WHERE username=?'); $s->execute([trim($_POST['username'] ?? '')]);
    $u=$s->fetch();
    if($u && password_verify($_POST['password'] ?? '',$u['password'])){
      session_regenerate_id(true); $_SESSION['admin']=$u['username']; header('Location: index.php'); exit;
    }
    $err='Username atau password salah.';
  }
}
top('Login');
?>
<h1>Login Admin</h1>
<?php if($err) echo '<div class="err">'.e($err).'</div>'; ?>
<form class="f" method="post">
<input type="hidden" name="t" value="<?= e(csrf()) ?>">
<label>Username</label><input type="text" name="username" required autofocus>
<label>Password</label><input type="password" name="password" required>
<p><button class="btn">Masuk</button> <a class="btn g" href="../index.php">Ke website</a></p>
</form>
<?php bottom();
