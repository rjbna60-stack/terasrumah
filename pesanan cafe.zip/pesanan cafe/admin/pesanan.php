<?php
require __DIR__.'/auth.php'; need_login();
$f=$_GET['s'] ?? '';
if($f!=='' && !array_key_exists($f,SS)) $f='';
$sql='SELECT * FROM pesanan'.($f?' WHERE status='.db()->quote($f):'').' ORDER BY id DESC LIMIT 200';
$rows=db()->query($sql)->fetchAll();
$h=db()->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM pesanan WHERE DATE(dibuat)=CURDATE() AND status_bayar='lunas' AND status<>'dibatalkan'")->fetch();
top('Pesanan');
?>
<h1>Pesanan masuk</h1>
<p>Hari ini: <b><?= (int)$h['c'] ?></b> pesanan lunas, pendapatan <b><?= rp($h['t']) ?></b></p>
<div class="nav"><a href="pesanan.php">Semua</a><?php foreach(SS as $k=>$v) echo '<a href="?s='.$k.'">'.e($v).'</a>'; ?></div>
<div class="wrap"><table>
<tr><th>Kode</th><th>Waktu</th><th>Pelanggan</th><th>Total</th><th>Metode</th><th>Bayar</th><th>Status</th></tr>
<?php foreach($rows as $r): ?>
<tr><td><a href="pesanan_detail.php?id=<?= (int)$r['id'] ?>"><b><?= e($r['kode']) ?></b></a></td>
<td><?= e(date('d/m H:i',strtotime($r['dibuat']))) ?></td>
<td><?= e($r['nama']) ?><br><small><?= $r['tipe']==='bawa_pulang'?'Bawa pulang':'Meja '.e($r['no_meja']) ?></small></td>
<td><?= rp($r['total']) ?></td><td><?= e(METODE[$r['metode']]) ?></td>
<td><?= pill_bayar($r['status_bayar']) ?></td><td><?= pill_status($r['status']) ?></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan="7">Belum ada pesanan.</td></tr>'; ?>
</table></div>
<script>setTimeout(function(){location.reload()},30000)</script>
<?php bottom();
