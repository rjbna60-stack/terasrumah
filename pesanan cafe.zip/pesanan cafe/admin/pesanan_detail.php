<?php
require __DIR__.'/auth.php'; need_login();
$id=(int)($_GET['id'] ?? 0);
$s=db()->prepare('SELECT * FROM pesanan WHERE id=?'); $s->execute([$id]); $o=$s->fetch();
if(!$o) exit('Pesanan tidak ditemukan');
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_ok()){
  if(isset($_POST['status']) && array_key_exists($_POST['status'],SS)) db()->prepare('UPDATE pesanan SET status=? WHERE id=?')->execute([$_POST['status'],$id]);
  if(isset($_POST['bayar']) && array_key_exists($_POST['bayar'],SB)) db()->prepare('UPDATE pesanan SET status_bayar=? WHERE id=?')->execute([$_POST['bayar'],$id]);
  header('Location: pesanan_detail.php?id='.$id.'&ok=1'); exit;
}
$s=db()->prepare('SELECT * FROM pesanan_item WHERE pesanan_id=?'); $s->execute([$id]); $items=$s->fetchAll();
$wa=preg_replace('/^0/','62',preg_replace('/[^0-9]/','',$o['no_hp']));
top('Pesanan '.$o['kode']);
?>
<div class="bar"><h1>Pesanan <?= e($o['kode']) ?></h1><a class="btn g" href="pesanan.php">&larr; Semua pesanan</a></div>
<?php if(isset($_GET['ok'])) echo '<div class="ok">Perubahan tersimpan.</div>'; ?>
<div class="grid2">
<div><table>
<tr><th colspan="2">Pelanggan</th></tr>
<tr><td>Nama</td><td><?= e($o['nama']) ?></td></tr>
<tr><td>HP</td><td><a href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener"><?= e($o['no_hp']) ?></a></td></tr>
<tr><td>Tipe</td><td><?= $o['tipe']==='bawa_pulang'?'Bawa pulang':'Makan di tempat, meja '.e($o['no_meja']) ?></td></tr>
<tr><td>Catatan</td><td><?= e($o['catatan'] ?: '-') ?></td></tr>
<tr><td>Waktu</td><td><?= e($o['dibuat']) ?></td></tr>
<tr><td>Metode</td><td><?= e(METODE[$o['metode']]) ?></td></tr>
</table></div>
<div><table>
<tr><th colspan="2">Rincian</th></tr>
<?php foreach($items as $i) echo '<tr><td>'.(int)$i['qty'].' &times; '.e($i['nama']).'</td><td>'.rp($i['harga']*$i['qty']).'</td></tr>'; ?>
<tr><td><b>Total</b></td><td><b><?= rp($o['total']) ?></b></td></tr></table></div>
</div>
<h2>Pembayaran <?= pill_bayar($o['status_bayar']) ?></h2>
<?php if($o['bukti']) echo '<p>Bukti dari pelanggan:<br><a href="../assets/bukti/'.e($o['bukti']).'" target="_blank"><img src="../assets/bukti/'.e($o['bukti']).'" alt="Bukti" style="max-width:260px;border-radius:10px"></a></p>'; elseif($o['metode']!=='tunai') echo '<p>Belum ada bukti pembayaran.</p>'; ?>
<form method="post" style="display:inline"><input type="hidden" name="t" value="<?= e(csrf()) ?>"><input type="hidden" name="bayar" value="lunas"><button class="btn">Tandai lunas</button></form>
<form method="post" style="display:inline"><input type="hidden" name="t" value="<?= e(csrf()) ?>"><input type="hidden" name="bayar" value="belum"><button class="btn g">Tandai belum bayar</button></form>
<h2>Status pesanan <?= pill_status($o['status']) ?></h2>
<form method="post"><input type="hidden" name="t" value="<?= e(csrf()) ?>">
<?php foreach(SS as $k=>$v) echo '<button class="btn'.($k==='dibatalkan'?' r':($k===$o['status']?'':' g')).'" name="status" value="'.$k.'">'.e($v).'</button> '; ?></form>
<?php bottom();
