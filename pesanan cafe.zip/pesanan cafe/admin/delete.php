<?php
require __DIR__.'/auth.php'; need_login();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_ok()){
  $id=(int)($_POST['id'] ?? 0);
  $s=db()->prepare('SELECT gambar FROM menu WHERE id=?'); $s->execute([$id]); $g=$s->fetchColumn();
  db()->prepare('DELETE FROM menu WHERE id=?')->execute([$id]);
  if($g && strpos($g,'menu_')===0 && is_file(__DIR__.'/../assets/img/'.$g)) @unlink(__DIR__.'/../assets/img/'.$g);
}
header('Location: index.php?ok=1');
