<?php
require __DIR__.'/auth.php'; need_login();
$rows=db()->query("SELECT * FROM menu ORDER BY FIELD(kategori,'makanan','minuman'), id")->fetchAll();
top('Kelola Menu');
?>
<div class="bar"><h1>Kelola Menu (<?= count($rows) ?>)</h1>
<div><a class="btn" href="form.php">+ Tambah menu</a> <a class="btn g" href="../index.php" target="_blank">Lihat website</a> <a class="btn g" href="logout.php">Keluar</a></div></div>
<?php if(isset($_GET['ok'])) echo '<div class="ok">Perubahan tersimpan.</div>'; ?>
<div class="wrap"><table>
<tr><th>Foto</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Status</th><th>Aksi</th></tr>
<?php foreach($rows as $r): ?>
<tr>
<td><img class="t" src="../assets/img/<?= e($r['gambar']) ?>" alt=""></td>
<td><?= e($r['nama']) ?><?= $r['favorit']?' &#9733;':'' ?></td>
<td><?= e($r['kategori']) ?></td>
<td>Rp <?= number_format($r['harga'],0,',','.') ?></td>
<td><?= $r['tersedia']?'Tampil':'Disembunyikan' ?></td>
<td><a class="btn g" href="form.php?id=<?= (int)$r['id'] ?>">Edit</a>
<form method="post" action="delete.php" style="display:inline" onsubmit="return confirm('Hapus menu ini?')">
<input type="hidden" name="t" value="<?= e(csrf()) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn r">Hapus</button></form></td>
</tr>
<?php endforeach; ?>
</table></div>
<?php bottom();
