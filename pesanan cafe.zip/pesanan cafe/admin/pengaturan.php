<?php
require __DIR__.'/auth.php'; need_login();
$set=pengaturan(); $err=''; $ok=isset($_GET['ok']);
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_ok()) $err='Sesi tidak valid.';
  $new=['bank_nama'=>trim($_POST['bank_nama'] ?? ''),'bank_rekening'=>trim($_POST['bank_rekening'] ?? ''),'bank_atas_nama'=>trim($_POST['bank_atas_nama'] ?? ''),'catatan_bayar'=>trim($_POST['catatan_bayar'] ?? '')];
  $f=$_FILES['qris'] ?? null;
  if(!$err && $f && $f['error']===UPLOAD_ERR_OK){
    [$n,$err]=simpan_gambar($f,__DIR__.'/../assets/img','qris_');
    if($n){ $old=$set['qris_gambar'] ?? ''; if($old && strpos($old,'qris_')===0) @unlink(__DIR__.'/../assets/img/'.$old); $new['qris_gambar']=$n; }
  }
  if(!$err){
    $st=db()->prepare('INSERT INTO pengaturan (kunci,nilai) VALUES (?,?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)');
    foreach($new as $k=>$v) $st->execute([$k,$v]);
    header('Location: pengaturan.php?ok=1'); exit;
  }
  $set=array_merge($set,$new);
}
top('Pembayaran');
?>
<h1>Pengaturan pembayaran</h1>
<?php if($ok) echo '<div class="ok">Pengaturan tersimpan.</div>'; if($err) echo '<div class="err">'.e($err).'</div>'; ?>
<form class="f" method="post" enctype="multipart/form-data"><input type="hidden" name="t" value="<?= e(csrf()) ?>">
<label>Nama bank</label><input type="text" name="bank_nama" value="<?= e($set['bank_nama'] ?? '') ?>">
<label>Nomor rekening</label><input type="text" name="bank_rekening" value="<?= e($set['bank_rekening'] ?? '') ?>">
<label>Atas nama</label><input type="text" name="bank_atas_nama" value="<?= e($set['bank_atas_nama'] ?? '') ?>">
<label>Gambar QRIS</label>
<?php $qrisImg=!empty($set['qris_gambar'])?$set['qris_gambar']:'qris_utama.png'; echo '<img src="../assets/img/'.e($qrisImg).'" alt="QRIS" style="max-width:180px;border-radius:10px;display:block;margin-bottom:6px">'; ?>
<input type="file" name="qris" accept="image/jpeg,image/png,image/webp">
<label>Catatan pembayaran (opsional)</label><textarea name="catatan_bayar" rows="3"><?= e($set['catatan_bayar'] ?? '') ?></textarea>
<p><button class="btn">Simpan</button></p></form>
<?php bottom();
