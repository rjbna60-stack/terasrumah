<?php
require_once __DIR__.'/../kasir_auth.php';
if (!empty($_SESSION['kasir'])) { header('Location: index.php'); exit; }
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 if (!isset($_POST['token'],$_SESSION['kasir_login_token']) || !hash_equals($_SESSION['kasir_login_token'],$_POST['token'])) $err='Sesi formulir kedaluwarsa. Muat ulang halaman dan coba lagi.';
 else { $st=db()->prepare('SELECT id,username,password FROM kasir WHERE username=? AND aktif=1 LIMIT 1'); $st->execute([trim((string)($_POST['username']??''))]); $u=$st->fetch();
  if ($u && password_verify((string)($_POST['password']??''),$u['password'])) { session_regenerate_id(true); $_SESSION['kasir']=['id'=>(int)$u['id'],'username'=>$u['username']]; unset($_SESSION['kasir_login_token']); header('Location: index.php'); exit; }
  $err='Username atau password kasir salah, atau akun dinonaktifkan.';
 }
}
$_SESSION['kasir_login_token']=bin2hex(random_bytes(24)); kasir_header('Verifikasi Kasir'); ?>
<section class="card login"><div style="font-size:34px">☕</div><h1>Verifikasi Kasir</h1><p class="muted">Masuk untuk mengelola pesanan dan memverifikasi pembayaran Teras Rumah.</p>
<?php if($err): ?><div class="notice err"><?=e($err)?></div><?php endif; ?>
<form method="post" autocomplete="on"><input type="hidden" name="token" value="<?=e($_SESSION['kasir_login_token'])?>"><label for="username">Username kasir</label><input id="username" name="username" required autocomplete="username" autofocus><label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password"><p style="margin-top:18px"><button class="btn" type="submit">Verifikasi &amp; Masuk</button></p></form>
<a href="../index.php">← Kembali ke menu pelanggan</a></section><?php kasir_footer(); ?>
