<?php
require_once __DIR__.'/../kasir_auth.php'; kasir_need_login();
$flash=''; $err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 if (!kasir_csrf_ok()) $err='Sesi tidak valid. Muat ulang halaman dan ulangi tindakan.';
 else { $id=(int)($_POST['id']??0); $action=(string)($_POST['action']??''); $st=db()->prepare('SELECT * FROM pesanan WHERE id=?'); $st->execute([$id]); $o=$st->fetch();
  if (!$o) $err='Pesanan tidak ditemukan.';
  elseif ($o['status']==='dibatalkan') $err='Pesanan yang dibatalkan tidak dapat diubah.';
  elseif ($action==='verify_payment') {
   if ($o['metode']!=='tunai' && empty($o['bukti'])) $err='Belum ada bukti pembayaran. Jangan tandai lunas sebelum bukti diterima dan diperiksa.';
   elseif ($o['status_bayar']==='lunas') $err='Pembayaran ini sudah ditandai lunas.';
   else { db()->prepare("UPDATE pesanan SET status_bayar='lunas' WHERE id=?")->execute([$id]); $flash='Pembayaran pesanan '.$o['kode'].' berhasil diverifikasi sebagai lunas.'; }
  } elseif ($action==='mark_unpaid') { db()->prepare("UPDATE pesanan SET status_bayar='belum' WHERE id=?")->execute([$id]); $flash='Status pembayaran dikembalikan menjadi belum dibayar.';
  } elseif ($action==='status' && in_array($_POST['status']??'', ['baru','diproses','siap','selesai'],true)) { db()->prepare('UPDATE pesanan SET status=? WHERE id=?')->execute([$_POST['status'],$id]); $flash='Status pesanan berhasil diperbarui.';
  } else $err='Tindakan tidak dikenali.';
 }
}
$f=(string)($_GET['status']??''); if(!in_array($f,['baru','diproses','siap','selesai','dibatalkan'],true)) $f='';
$w=$f?' WHERE status=?':''; $q=db()->prepare('SELECT * FROM pesanan'.$w.' ORDER BY id DESC LIMIT 300'); $q->execute($f?[$f]:[]); $orders=$q->fetchAll();
$stats=db()->query("SELECT COUNT(*) total, COALESCE(SUM(status_bayar='menunggu_verifikasi'),0) pending, COALESCE(SUM(CASE WHEN status_bayar='lunas' AND status<>'dibatalkan' AND DATE(dibuat)=CURDATE() THEN total ELSE 0 END),0) omzet FROM pesanan")->fetch();
kasir_header('Panel Kasir'); ?>
<div class="top"><div><h1>Panel Kasir Teras Rumah</h1><div class="muted">Login sebagai <?=e($_SESSION['kasir']['username'])?> · Kelola pesanan dan verifikasi pembayaran</div></div><div class="row"><a class="btn secondary" href="../index.php" target="_blank" rel="noopener">Website pelanggan</a><a class="btn danger" href="logout.php">Keluar</a></div></div>
<?php if($flash): ?><div class="notice ok"><?=e($flash)?></div><?php endif; ?><?php if($err): ?><div class="notice err"><?=e($err)?></div><?php endif; ?>
<div class="stats"><div class="stat"><span class="muted">Total pesanan</span><strong><?= (int)$stats['total']?></strong></div><div class="stat"><span class="muted">Menunggu verifikasi</span><strong><?= (int)$stats['pending']?></strong></div><div class="stat"><span class="muted">Pendapatan lunas hari ini</span><strong><?=rp($stats['omzet'])?></strong></div></div>
<section class="card"><div class="top" style="margin-bottom:10px"><h2 style="margin:0">Daftar Pesanan</h2><form class="row" method="get"><select name="status" aria-label="Filter status" style="width:auto"><option value="">Semua status</option><?php foreach(['baru'=>'Baru','diproses'=>'Diproses','siap'=>'Siap','selesai'=>'Selesai','dibatalkan'=>'Dibatalkan'] as $k=>$v): ?><option value="<?=e($k)?>" <?=$f===$k?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select><button class="btn secondary" type="submit">Filter</button></form></div>
<div class="table-wrap"><table><thead><tr><th>Kode / Waktu</th><th>Pelanggan</th><th>Rincian</th><th>Pembayaran</th><th>Status pesanan</th><th>Aksi kasir</th></tr></thead><tbody>
<?php foreach($orders as $o): $items=db()->prepare('SELECT nama,qty,harga FROM pesanan_item WHERE pesanan_id=?'); $items->execute([$o['id']]); $its=$items->fetchAll(); ?>
<tr><td><b><?=e($o['kode'])?></b><br><small><?=e(date('d/m/Y H:i',strtotime($o['dibuat'])))?></small></td><td><?=e($o['nama'])?><br><small><?=e($o['no_hp'])?></small><br><small><?= $o['tipe']==='bawa_pulang'?'Bawa pulang':'Meja '.e($o['no_meja']?:'-') ?></small></td>
<td><?php foreach($its as $it): ?><div><?= (int)$it['qty']?> × <?=e($it['nama'])?></div><?php endforeach; ?><b>Total: <?=rp($o['total'])?></b><?php if($o['catatan']): ?><br><small>Catatan: <?=e($o['catatan'])?></small><?php endif; ?></td>
<td><?=e(METODE[$o['metode']]??$o['metode'])?><br><?php if($o['status_bayar']==='lunas'): ?><span class="pill ok">Lunas</span><?php elseif($o['status_bayar']==='menunggu_verifikasi'): ?><span class="pill warn">Menunggu verifikasi</span><?php else: ?><span class="pill">Belum dibayar</span><?php endif; ?><?php if($o['bukti']): ?><br><a href="../assets/bukti/<?=e($o['bukti'])?>" target="_blank" rel="noopener">Lihat bukti</a><?php elseif($o['metode']!=='tunai'): ?><br><small class="muted">Bukti belum diunggah</small><?php endif; ?></td>
<td><span class="pill <?= $o['status']==='selesai'?'ok':($o['status']==='dibatalkan'?'bad':($o['status']==='baru'?'warn':'')) ?>"><?=e(SS[$o['status']]??$o['status'])?></span><form method="post" class="row" style="margin-top:8px"><input type="hidden" name="token" value="<?=e(kasir_csrf())?>"><input type="hidden" name="id" value="<?=(int)$o['id']?>"><input type="hidden" name="action" value="status"><select name="status" aria-label="Ubah status pesanan" style="min-width:125px"><?php foreach(['baru'=>'Baru','diproses'=>'Diproses','siap'=>'Siap','selesai'=>'Selesai'] as $k=>$v): ?><option value="<?=e($k)?>" <?=$o['status']===$k?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select><button class="btn small" type="submit">Simpan</button></form></td>
<td><?php if($o['status_bayar']!=='lunas'): ?><form method="post" onsubmit="return confirm('Pastikan pembayaran sudah diterima dan bukti sesuai. Tandai lunas?')"><input type="hidden" name="token" value="<?=e(kasir_csrf())?>"><input type="hidden" name="id" value="<?=(int)$o['id']?>"><input type="hidden" name="action" value="verify_payment"><button class="btn small" type="submit">Verifikasi / Lunas</button></form><?php else: ?><form method="post" onsubmit="return confirm('Ubah pembayaran menjadi belum dibayar?')"><input type="hidden" name="token" value="<?=e(kasir_csrf())?>"><input type="hidden" name="id" value="<?=(int)$o['id']?>"><input type="hidden" name="action" value="mark_unpaid"><button class="btn secondary small" type="submit">Batalkan verifikasi</button></form><?php endif; ?></td></tr>
<?php endforeach; if(!$orders): ?><tr><td colspan="6">Belum ada pesanan untuk filter ini.</td></tr><?php endif; ?>
</tbody></table></div><p class="muted">Halaman diperbarui otomatis setiap 30 detik. Untuk transfer/QRIS, periksa bukti pembayaran sebelum menekan “Verifikasi / Lunas”.</p></section><script>setTimeout(function(){location.reload()},30000)</script><?php kasir_footer(); ?>
