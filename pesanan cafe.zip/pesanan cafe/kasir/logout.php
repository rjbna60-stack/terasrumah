<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
unset($_SESSION['kasir'],$_SESSION['kasir_token']);
header('Location: login.php'); exit;
