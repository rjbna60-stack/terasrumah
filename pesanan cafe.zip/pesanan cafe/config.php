<?php
// Pengaturan database XAMPP bawaan (user root, tanpa password)
const DB_HOST='localhost', DB_NAME='teras_rumah', DB_USER='root', DB_PASS='';
function db(){
  static $p=null;
  if(!$p){
    try{
      $p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    }catch(PDOException $e){
      http_response_code(500);
      exit('Koneksi database gagal. Pastikan MySQL di XAMPP aktif dan database teras_rumah sudah di-import.');
    }
  }
  return $p;
}

if(!function_exists('mb_strlen')){ function mb_strlen($s){ return strlen($s); } }
function e($s){ return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8'); }
function rp($n){ return 'Rp '.number_format((int)$n,0,',','.'); }
function pengaturan(){ try{ return db()->query('SELECT kunci,nilai FROM pengaturan')->fetchAll(PDO::FETCH_KEY_PAIR); }catch(Exception $x){ return []; } }
const SB=['belum'=>'Belum dibayar','menunggu_verifikasi'=>'Menunggu verifikasi','lunas'=>'Lunas'];
const SS=['baru'=>'Baru','diproses'=>'Diproses','siap'=>'Siap','selesai'=>'Selesai','dibatalkan'=>'Dibatalkan'];
const METODE=['tunai'=>'Tunai di kasir','transfer'=>'Transfer bank','qris'=>'QRIS'];
function simpan_gambar($f,$dir,$prefix){
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime] ?? null;
  if(!$ext) return [null,'Foto harus JPG, PNG, atau WEBP.'];
  if($f['size']>3*1024*1024) return [null,'Ukuran foto maksimal 3 MB.'];
  $n=$prefix.bin2hex(random_bytes(6)).'.'.$ext;
  return move_uploaded_file($f['tmp_name'],$dir.'/'.$n) ? [$n,null] : [null,'Gagal menyimpan foto.'];
}
