<?php
require_once __DIR__.'/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function kasir_need_login(){
  if (empty($_SESSION['kasir'])) { header('Location: login.php'); exit; }
}
function kasir_csrf(){
  if (empty($_SESSION['kasir_token'])) $_SESSION['kasir_token']=bin2hex(random_bytes(24));
  return $_SESSION['kasir_token'];
}
function kasir_csrf_ok(){
  return isset($_POST['token'],$_SESSION['kasir_token']) && hash_equals($_SESSION['kasir_token'],$_POST['token']);
}
function kasir_header($title){
  echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' - Kasir Teras Rumah</title><style>
  :root{--bg:#f5f4ee;--card:#fff;--ink:#26332b;--muted:#68756b;--green:#6f9d84;--line:#e3e6dc;--gold:#c8923b;--red:#b93832}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,sans-serif}.wrap{max-width:1120px;margin:auto;padding:22px}h1{font-size:25px;margin:0}h2{font-size:19px;margin:20px 0 10px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:18px}.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:16px}.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.stat{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px}.stat strong{display:block;font-size:23px}.muted{color:var(--muted)}.btn{display:inline-block;border:0;border-radius:9px;padding:9px 13px;background:var(--green);color:#14251b;text-decoration:none;font-weight:700;cursor:pointer;font:inherit;font-weight:700}.btn.secondary{background:#e8e9df}.btn.danger{background:#f3d5d2;color:#84251f}.btn.small{padding:6px 9px;font-size:13px}input,select{padding:10px;border:1px solid #cfd5c8;border-radius:8px;font:inherit;width:100%;background:#fff}label{display:block;font-weight:650;margin:10px 0 5px}.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;background:#fff}th,td{text-align:left;padding:11px;border-bottom:1px solid var(--line);vertical-align:top}th{background:#edf0e8;font-size:13px}.pill{display:inline-block;padding:3px 9px;border-radius:99px;background:#e8e9df;font-size:12px;font-weight:700}.pill.warn{background:#ffedc2}.pill.ok{background:#cce8d6}.pill.bad{background:#f3d5d2}.notice{padding:11px 14px;border-radius:9px;margin:12px 0}.notice.ok{background:#dff0e5}.notice.err{background:#fbe2df;color:#85251d}.proof{max-width:240px;max-height:220px;object-fit:contain;border-radius:8px;border:1px solid var(--line)}.login{max-width:420px;margin:7vh auto}.login h1{margin-bottom:5px}@media(max-width:650px){.wrap{padding:14px}.stats{grid-template-columns:1fr}.top h1{font-size:22px}}
  </style></head><body><main class="wrap">';
}
function kasir_footer(){ echo '</main></body></html>'; }
